﻿namespace CarwashLaCocoa
{
    public partial class MainPage : ContentPage
    {
        private string username = "";
        private string password = "";

        private string loginUsername = "";
        private string loginPassword = "";

        Dictionary<string, string> users = new Dictionary<string, string>();
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnRegistrationTextChanged(object sender, TextChangedEventArgs e)
        {
            Entry entry = (Entry)sender;
            if (entry == usernameEntry)
            {
                usernameErrorLabel.IsVisible = false;
                usernameErrorLabel.Text = "";
                username = e.NewTextValue;
            }
            else if (entry == passwordEntry)
            {
                passwordErrorLabel.IsVisible = false;
                passwordErrorLabel.Text = "";
                password = e.NewTextValue;
            }
        }

        private void OnRegistrationSubmit(object sender, EventArgs e)
        {
            if (username.Length < 6)
            {
                usernameErrorLabel.IsVisible = true;
                usernameErrorLabel.Text = "El nombre de usuario debe tener al menos 6 caracteres.";
                return;
            }
            else if (password.Length < 8)
            {
                passwordErrorLabel.IsVisible = true;
                passwordErrorLabel.Text = "La contraseña debe tener al menos 8 caracteres.";
                return;
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(password, "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).+$"))
            {
                passwordErrorLabel.IsVisible = true;
                passwordErrorLabel.Text = "La contraseña debe contener al menos una letra mayúscula, minuscula y un numero.";
                return;
            }
            else
            {
                usernameErrorLabel.IsVisible = false;
                passwordErrorLabel.IsVisible = false;
                Registration.IsVisible = false;
                Login.IsVisible = true;

                users.Add(username, password);
            }
        }

        private void OnLoginTextChanged(object sender, TextChangedEventArgs e)
        {
            Entry entry = (Entry)sender;
            if (entry == usernameLoginEntry)
            {
                usernameLoginErrorLabel.Text = "";
                usernameLoginErrorLabel.IsVisible = false;
                loginUsername = e.NewTextValue;
            }
            else if (entry == passwordLoginEntry)
            {
                passwordLoginErrorLabel.Text = "";
                passwordLoginErrorLabel.IsVisible = false;
                loginPassword = e.NewTextValue;
            }
        }

        private void OnLoginSubmit(object sender, EventArgs e)
        {
            if (users.ContainsKey(loginUsername))
            {
                if (users[loginUsername] == loginPassword)
                {
                    LoggedUsername.Text = $"¡Bienvenido {loginUsername}!";
                    Login.IsVisible = false;
                    HomePage.IsVisible = true;
                }
                else
                {
                    passwordLoginErrorLabel.Text = "Contraseña Incorrecta";
                    passwordLoginErrorLabel.IsVisible = true;
                }
            }
            else
            {
                usernameLoginErrorLabel.Text = "Usuario no existe";
                usernameLoginErrorLabel.IsVisible = true;
            }
        }
        private void OnGoToRegistration(object sender, EventArgs e)
        {
            ClearEntries();
            Login.IsVisible = false;
            Registration.IsVisible = true;
        }

        private void OnGoToLogin(object sender, EventArgs e)
        {
            ClearEntries();
            Registration.IsVisible = false;
            Login.IsVisible = true;
        }

        private void OnLogout(object sender, EventArgs e)
        {
            ClearEntries();
            HomePage.IsVisible = false;
            Login.IsVisible = true;
        }

        private void ClearEntries()
        {
            usernameEntry.Text = "";
            passwordEntry.Text = "";
            usernameLoginEntry.Text = "";
            passwordLoginEntry.Text = "";
        }
    }
}
