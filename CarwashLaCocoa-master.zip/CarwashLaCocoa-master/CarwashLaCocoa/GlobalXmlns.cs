[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "CarwashLaCocoa")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "CarwashLaCocoa.Pages")]
